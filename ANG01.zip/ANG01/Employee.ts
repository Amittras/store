class Employee
{
    empID: number; 
    empName: string; 

    constructor(empID: number, empName: string)
    {
        this.empID=empID; 
        this.empName=empName; 
    }
    constructor(ID: number)
    {
        this.empID=ID; 
    }
    display=()=> console.log(this.empID+': '+this.empName); 
}

let e = new Employee(1001, 'Soham'); 
e.display(); 