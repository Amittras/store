function display() {
    console.log("Hello");
}
display();
