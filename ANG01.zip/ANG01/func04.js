function add(a, b) {
    return a + b;
}
console.log(add('hello', 'soham'));
console.log(add(10, 20));
