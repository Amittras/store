//THE ARROW FUNCTION. 

let sum = (x:number,y:number) =>{    return x+y;     };           // '=>' is the thing. 
//write the above as 
    //  let sum=(x:number, y:number)=>x+y; 

let display =()=>console.log('Hello!');             //braces are optional for a single statement. 

console.log(sum(10,210));
display(); 