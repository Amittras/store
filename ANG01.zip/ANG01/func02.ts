//parameterized function
//PROTOTYPE

//function function_name (param_name: param_type, (other parameters)): return_type {  ...other logic...}
function Sum(x:number, y:number): number{   
    return x+y; 
}

console.log(Sum(2,4));                      //call to the function. 