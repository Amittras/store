//TS Sets. 
//Sets contain only unique elements by definition. 

/*Explicit installation of 'typescript-collections': 
        LOC:> npm i typescript-collections
    Local installation!
*/

import {Set} from 'typescript-collections';         //importing required libraries. 
let sample = new Set();                             //declaraing the new set.
sample.add(1);                                      //adding elements   -->only uniques will be added. 
sample.add(2);
sample.add(3);
sample.add(4);
sample.add(3);
sample.add(1); 

sample.forEach(function(value){                        //A lambda-expression for traversing. 
        console.log(value);
    }); 