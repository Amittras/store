function display(){             //defining the function
    console.log("Hello");
}

display();                      //calling the function. 