//TS more ARRAY OPERATIONS. 
let sample1: number[] = [1,3,5,7,9,11,13,15] ;
let sample2: number[] = [1,3,5,7,9,11,13,15] ;
let cloneAr = [...sample1];              //SPREAD OPERATOR 

console.log(cloneAr);                   //printing array directly. 

//-------------------------------------------------------------------------------------------------
let otherClone = [...sample1,  ...sample2]   //merging the two arrays. 
console.log(otherClone); 

//-------------------------------------------------------------------------------------------------
