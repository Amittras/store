function Sum(x, y) {
    return x + y;
}
console.log(Sum(2, 4));
