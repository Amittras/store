var sum = function (x, y) { return x + y; };
var display = function () { return console.log('Hello!'); };
console.log(sum(10, 210));
display();
