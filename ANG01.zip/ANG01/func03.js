var greet = function () {
    console.log("Some text to display!");
};
greet();
var Sum2 = function (x, y) {
    return x + y;
};
console.log(Sum2(2, 4));
