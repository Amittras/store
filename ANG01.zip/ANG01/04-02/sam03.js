var a;
a = ["apple", "orange", "banana", "pineapple", "blueberry", "strawberry"];
a.push('mango');
a.splice(a.indexOf('mango'), 1);
for (var _i = 0, a_1 = a; _i < a_1.length; _i++) {
    var i = a_1[_i];
    console.log(i);
}
console.log('----------------------------');
console.log(a.slice(2, 4));
