//TS enhanced loops & arrays demonstrations. 

var a : Array<String>;      //array declaration. 
a= ["apple", "orange", "banana", "pineapple", "blueberry", "strawberry"];   //array definition. 

a.push('mango');        //adding a new element to array, added at last. 
 
//a.sort();                               //sorting natural order.

//Another Method -->>       
//      let a = ["apple", "orange", "banana", "pineapple", "blueberry", "strawberry"];
//-------------------------------------------------------------------------------------------------
//for(let i of a)
   //console.log(i);     //i assumes the "data" values of the elements.

    /*Another Method: 
        for(let i in a)
            console.log(a[i]); 
    */
//-------------------------------------------------------------------------------------------------
/*
for(let i in a)
    console.log(i);     //i assumes the "index" values of the elements.


    /* 
    a 'var' type of declaration is for the entire page, 
        -->> thus I suggest myself to use a 'let' type of variable for looping locales. 
    */
//-------------------------------------------------------------------------------------------------
//a.pop();                                                     //remove last element.

//-------------------------------------------------------------------------------------------------
a.splice(a.indexOf('mango'), 1);            //removes 'mango'. 
for(let i of a)
    console.log(i);
//-------------------------------------------------------------------------------------------------
console.log('----------------------------');
console.log(a.slice(2,4));


     