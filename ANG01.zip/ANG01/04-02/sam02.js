var name2 = "Amittras";
var ID = 1234;
var sal = 123.456;
console.log(name2);
console.log(ID);
console.log(sal);
