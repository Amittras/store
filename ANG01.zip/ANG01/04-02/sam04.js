var sample = [1, 3, 5, 7, 9, 11, 13, 15];
var sample2 = [1, 3, 5, 7, 9, 11, 13, 15];
var cloneAr = sample.slice();
console.log(cloneAr);
var otherClone = sample.concat(sample2);
console.log(otherClone);
