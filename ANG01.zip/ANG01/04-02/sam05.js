"use strict";
exports.__esModule = true;
var typescript_collections_1 = require("typescript-collections");
var sample = new typescript_collections_1.Set();
sample.add(1);
sample.add(2);
sample.add(3);
sample.add(4);
sample.add(3);
sample.add(1);
sample.forEach(function (value) {
    console.log(value);
});
