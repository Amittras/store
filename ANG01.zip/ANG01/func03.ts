//Anonymous Function & Expression Format
//--------------------------------------------------------------------------------------------
//these are sometimes used in class dclarations. 

let greet = function(){                     //this is expression format. 
    console.log("Some text to display!"); 
};                  //the ';' is optional. 
// ---> Function declaration is in terms of an expression. 
greet(); 

//CAN ALSO DO WITH PARAMETERIZED FUNCTIONS, absolutely same. 

let Sum2 = function(x:number, y:number): number{   
    return x+y; 
}

console.log(Sum2(2,4));                        //calling the PARAMETERIZED-ANONYMOUS function. 