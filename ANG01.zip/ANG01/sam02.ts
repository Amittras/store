var name2: String="Amittras"; 
var ID: number=1234; 
var sal: number=123.456; 

console.log(name2);
console.log(ID);
console.log(sal);