import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagexxComponent } from './pagexx.component';

describe('PagexxComponent', () => {
  let component: PagexxComponent;
  let fixture: ComponentFixture<PagexxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagexxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagexxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
