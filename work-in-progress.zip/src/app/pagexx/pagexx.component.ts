import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagexx',
  templateUrl: './pagexx.component.html',
  styleUrls: ['./pagexx.component.css']
})
export class PagexxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
